// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: always_specify_types, implicit_dynamic_parameter

part of 'commit.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Map<String, dynamic> _$SerializableCommitToJson(SerializableCommit instance) => <String, dynamic>{
      'Key': const StringKeyConverter().toJson(instance.key),
      'Checklist': instance.facade,
    };
