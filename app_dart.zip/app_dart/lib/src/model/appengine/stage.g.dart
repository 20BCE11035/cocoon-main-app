// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: always_specify_types, implicit_dynamic_parameter

part of 'stage.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Map<String, dynamic> _$StageToJson(Stage instance) => <String, dynamic>{
      'Name': instance.name,
      'Tasks': instance.serializableTasks,
      'Status': instance.taskStatus,
    };
