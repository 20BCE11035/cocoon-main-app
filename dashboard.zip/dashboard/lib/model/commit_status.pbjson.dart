///
//  Generated code. Do not modify.
//  source: lib/model/commit_status.proto
//
// @dart = 2.12
// ignore_for_file: annotate_overrides,camel_case_types,unnecessary_const,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type,unnecessary_this,prefer_final_fields,deprecated_member_use_from_same_package

import 'dart:core' as $core;
import 'dart:convert' as $convert;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use commitStatusDescriptor instead')
const CommitStatus$json = {
  '1': 'CommitStatus',
  '2': [
    {'1': 'commit', '3': 1, '4': 1, '5': 11, '6': '.Commit', '10': 'commit'},
    {'1': 'tasks', '3': 2, '4': 3, '5': 11, '6': '.Task', '10': 'tasks'},
    {'1': 'branch', '3': 3, '4': 1, '5': 9, '10': 'branch'},
  ],
};

/// Descriptor for `CommitStatus`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List commitStatusDescriptor = $convert.base64Decode(
    'CgxDb21taXRTdGF0dXMSHwoGY29tbWl0GAEgASgLMgcuQ29tbWl0UgZjb21taXQSGwoFdGFza3MYAiADKAsyBS5UYXNrUgV0YXNrcxIWCgZicmFuY2gYAyABKAlSBmJyYW5jaA==');
