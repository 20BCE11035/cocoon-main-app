# Autosubmit

RFC is available in https://flutter.dev/go/autosubmit
